import React, { createContext, useState, useContext, useEffect } from "react";

const FavoritesContext = createContext();

export const FavoritesProvider = ({ children }) => {
  // 1. Initial State: Load from localStorage on startup
  const [favorites, setFavorites] = useState(() => {
    const localData = localStorage.getItem("favorites");
    return localData ? JSON.parse(localData) : [];
  });

  // 2. Persistence: Update localStorage whenever favorites change
  useEffect(() => {
    localStorage.setItem("favorites", JSON.stringify(favorites));
  }, [favorites]);

  // --- FUNCTIONS ---

  // Adds a product to the list if not already present
  const addToFavorites = (product) => {
    if (!favorites.find((item) => item.id === product.id)) {
      setFavorites([...favorites, product]);
    }
  };

  // Removes a product from the list by filtering ID
  const removeFromFavorites = (productId) => {
    setFavorites(favorites.filter((item) => item.id !== productId));
  };

  // Logic to either add or remove based on current status
  const toggleFavorite = (product) => {
    const exists = favorites.find((item) => item.id === product.id);
    if (exists) {
      removeFromFavorites(product.id);
    } else {
      addToFavorites(product);
    }
  };

  // Check if a specific product is in the favorites
  const isFavorite = (productId) => {
    return favorites.some((item) => item.id === productId);
  };

  const values = {
    favorites,
    addToFavorites,
    removeFromFavorites,
    toggleFavorite,
    isFavorite,
  };

  return (
    <FavoritesContext.Provider value={values}>
      {children}
    </FavoritesContext.Provider>
  );
};

// Hook for easy access to favorites data
export const useFavorites = () => useContext(FavoritesContext);