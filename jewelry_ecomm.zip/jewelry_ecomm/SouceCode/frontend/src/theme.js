import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: { main: '#000000ff' },
    secondary: { main: '#ffffffff' }
  },
  components: {
    MuiAppBar: {
      defaultProps: {
        elevation: 1
      }
    }
  }
});

export default theme;
