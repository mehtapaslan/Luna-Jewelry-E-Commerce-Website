import React from "react";
import { Link } from "react-router-dom";

// Material UI Components
import { Card, CardMedia, CardContent, Typography, CardActions, Button, Box, IconButton } from "@mui/material";

// Icons
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import FavoriteIcon from "@mui/icons-material/Favorite";

// Context & Config
import { useCart } from "../context/CartContext";
import { useFavorites } from "../context/FavoritesContext";
import { resolveImageUrl } from "../config";

export default function ProductCard({ product }) {
  // Destructuring product for cleaner code
  const { id, name, description, price, imageUrl } = product;
  
  const { add } = useCart();
  const { toggleFavorite, isFavorite } = useFavorites();
  const isLiked = isFavorite(id);

  // Handle favorite click without triggering the card's link navigation
  const handleFavoriteClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite(product);
  };

  return (
    <Card 
      sx={{
        maxWidth: 280,
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: "none", 
        borderRadius: 0, 
        position: "relative",
        transition: '0.3s ease-in-out',
        bgcolor: 'transparent',
        overflow: 'hidden',
        '&:hover': {
          outline: "1px solid #000", 
          outlineOffset: "-1px"
        },
        // Show hidden content on hover
        '&:hover .hover-content': { 
          opacity: 1,
          visibility: 'visible'
        }
      }}
    >
      
      {/* Media Section: Contains Product Image and Favorite Toggle */}
      <Box sx={{ position: "relative", overflow: 'hidden' }}>
        
        <IconButton 
          className="hover-content"
          onClick={handleFavoriteClick}
          sx={{ 
            position: "absolute", 
            top: 10, 
            right: 10, 
            zIndex: 2,
            bgcolor: 'rgba(255,255,255,0.8)',
            opacity: 0,
            visibility: 'hidden',
            transition: '0.3s',
            '&:hover': { bgcolor: 'white' }
          }} 
        >
          {isLiked ? (
            <FavoriteIcon sx={{ color: "red", fontSize: "1.1rem" }} />
          ) : (
            <FavoriteBorderIcon sx={{ color: "#333", fontSize: "1.1rem" }} />
          )}
        </IconButton>

        <Link to={`/products/${id}`} style={{ textDecoration: 'none' }}>
          <CardMedia
            component="img"
            height="280"
            image={resolveImageUrl(imageUrl)}
            alt={name}
            sx={{ objectFit: "cover", width: "100%" }} 
          />
        </Link>
      </Box>

      {/* Content Section: Product details */}
      <CardContent sx={{ flexGrow: 1, textAlign: 'center', pt: 2 }}>
        <Typography 
          variant="h6" 
          sx={{ 
            fontWeight: "bold", 
            textTransform: "uppercase", 
            letterSpacing: 1.5, 
            fontSize: "0.85rem",
            color: "#000"
          }}
        >
          {name}
        </Typography>

        <Typography 
          variant="body2" 
          color="text.secondary" 
          sx={{ 
            fontFamily: "'Playfair Display', serif",
            fontStyle: "italic", 
            fontSize: "0.8rem",
            mt: 0.5 
          }}
        >
          {description}
        </Typography>

        <Typography 
          variant="h6" 
          sx={{ fontWeight: "bold", mt: 1, color: "#000", fontSize: "0.95rem" }}
        >
          ${price?.toLocaleString()}
        </Typography>
      </CardContent>

      {/* Action Section: Interaction buttons shown on hover */}
      <CardActions 
        className="hover-content"
        sx={{ 
          justifyContent: 'center', 
          pb: 2, 
          gap: 1,
          opacity: 0,
          visibility: 'hidden',
          transition: '0.3s ease-in-out'
        }}
      >
        <Button 
          variant="contained"
          onClick={() => add(product)}
          sx={{ 
            bgcolor: "black", 
            color: "white", 
            borderRadius: 0, 
            textTransform: "uppercase",
            fontSize: "0.65rem",
            px: 1.5,
            "&:hover": { bgcolor: "#333" } 
          }}
        >
          Add to cart
        </Button>
        
        <Button
          variant="outlined" 
          component={Link}
          to={`/products/${id}`}
          sx={{ 
            borderRadius: 0, 
            borderColor: "black", 
            color: "black",
            fontSize: "0.65rem",
            px: 1.5,
            "&:hover": { borderColor: "#333", bgcolor: "rgba(0,0,0,0.05)" }
          }}
        >
          Discover
        </Button>
      </CardActions>
    </Card>
  );
}