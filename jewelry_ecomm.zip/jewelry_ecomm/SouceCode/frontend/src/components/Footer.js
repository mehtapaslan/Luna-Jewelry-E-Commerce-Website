import React from "react";
import { Box, Container, Typography, IconButton, TextField, Button, Stack } from "@mui/material";
import { Instagram, Facebook, Twitter, Pinterest } from "@mui/icons-material";

// Social media configuration for easier maintenance
const SOCIAL_LINKS = [
  { icon: <Instagram />, label: "Instagram" },
  { icon: <Pinterest />, label: "Pinterest" },
  { icon: <Facebook />, label: "Facebook" },
  { icon: <Twitter />, label: "Twitter" },
];

export default function Footer() {
  return (
    <Box
      component="footer"
      sx={{
        backgroundColor: "#000",
        color: "#fff",
        py: 8,
        mt: 'auto',
        textAlign: 'center'
      }}
    >
      <Container maxWidth="sm">
        
        {/* Brand Identity Section */}
        <Typography 
          variant="h4" 
          sx={{ 
            fontFamily: "'Playfair Display', serif", 
            fontStyle: "italic", 
            mb: 2 
          }}
        >
          Luna Jewelry
        </Typography>

        {/* Newsletter Header */}
        <Typography variant="body1" sx={{ color: "#999", mb: 4, lineHeight: 1.6 }}>
          Subscribe to our newsletter to receive exclusive offers, 
          latest news and updates.
        </Typography>
        
        {/* Subscription Form Group */}
        <Box sx={{ display: 'flex', mb: 6 }}>
          <TextField 
            variant="outlined" 
            placeholder="Email address" 
            fullWidth
            sx={{ 
              bgcolor: 'rgba(255,255,255,0.1)', 
              borderRadius: 0,
              input: { color: 'white', padding: '12px 14px' },
              '& .MuiOutlinedInput-notchedOutline': { border: 'none' } 
            }} 
          />
          <Button 
            variant="contained" 
            sx={{ 
              bgcolor: '#fff', 
              color: '#000', 
              borderRadius: 0,
              px: 4,
              textTransform: 'uppercase',
              letterSpacing: 1,
              fontWeight: 'bold',
              '&:hover': { bgcolor: '#ddd' }
            }}
          >
            Join
          </Button>
        </Box>

        {/* Social Media Links - Rendered dynamically from array */}
        <Stack direction="row" spacing={2} justifyContent="center" sx={{ mb: 4 }}>
          {SOCIAL_LINKS.map((social, index) => (
            <IconButton 
              key={index} 
              color="inherit" 
              aria-label={social.label}
              sx={{ '&:hover': { color: '#ccc' } }}
            >
              {social.icon}
            </IconButton>
          ))}
        </Stack>

        {/* Copyright Information */}
        <Typography variant="caption" sx={{ color: "#555", letterSpacing: 1 }}>
          © {new Date().getFullYear()} LUNA JEWELRY. ALL RIGHTS RESERVED.
        </Typography>

      </Container>
    </Box>
  );
}