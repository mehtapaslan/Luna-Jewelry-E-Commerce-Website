import { useEffect } from "react";
import { useLocation } from "react-router-dom";

/**
 * ScrollToTop Component
 * Ensures the window scrolls back to the top (0,0) whenever the route changes.
 */
export default function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    // Reset scroll position to top-left corner on every navigation change
    window.scrollTo(0, 0);
  }, [pathname]);

  // This component handles logic only and does not render any UI elements
  return null;
}