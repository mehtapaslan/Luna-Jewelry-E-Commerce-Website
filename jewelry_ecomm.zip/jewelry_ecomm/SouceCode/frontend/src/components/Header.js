import React from "react";
import { Link, useNavigate } from "react-router-dom";

// Material UI Components
import { AppBar, Toolbar, Typography, IconButton, Badge, Box, Tooltip } from "@mui/material";

// Icons
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

// Context Hooks
import { useCart } from "../context/CartContext";
import { useFavorites } from "../context/FavoritesContext";

export default function Header() {
  const { items } = useCart();
  const { favorites } = useFavorites();
  const navigate = useNavigate();

  // Calculate total counts for Cart and Favorites
  const totalCount = items.reduce((sum, item) => sum + (item.quantity || 1), 0);
  const favoriteCount = favorites ? favorites.length : 0;

  return (
    <AppBar 
      position="sticky" 
      elevation={0}
      sx={{ 
        backgroundColor: "#ffffff", 
        borderBottom: "1px solid #f0f0f0",
        px: { xs: 1, md: 5 },
        py: 1
      }}
    >
      <Toolbar disableGutters sx={{ display: "flex", alignItems: "center" }}>
        
        {/* LEFT SECTION: Navigation controls */}
        <Box sx={{ flex: 1, display: "flex", alignItems: "center", gap: 1 }}>
          <Tooltip title="Back">
            <IconButton 
              onClick={() => navigate(-1)} 
              sx={{ 
                color: "#000", 
                "&:hover": { bgcolor: "rgba(0,0,0,0.04)" } 
              }}
            >
              <ArrowBackIosNewIcon sx={{ fontSize: "1.2rem" }} />
            </IconButton>
          </Tooltip>

          <Tooltip title="Forward">
            <IconButton 
              onClick={() => navigate(1)} 
              sx={{ 
                color: "#000", 
                "&:hover": { bgcolor: "rgba(0,0,0,0.04)" } 
              }}
            >
              <ArrowForwardIosIcon sx={{ fontSize: "1.2rem" }} />
            </IconButton>
          </Tooltip>
        </Box>

        {/* CENTER SECTION: Branding/Logo */}
        <Box sx={{ flex: 2, textAlign: "center" }}>
          <Typography
            component={Link}
            to="/"
            sx={{ 
              textDecoration: "none", 
              color: "#000",
              fontFamily: "'Pinyon Script', cursive", 
              fontSize: { xs: "2.5rem", md: "3.5rem" },
              fontWeight: 400, 
              lineHeight: 1,
              display: "inline-block",
              transform: "translateY(5px)"
            }}
          >
            Luna
          </Typography>
        </Box>

        {/* RIGHT SECTION: User actions (Favorites & Cart) */}
        <Box sx={{ flex: 1, display: "flex", justifyContent: "flex-end", gap: 2 }}>
          
          {/* Favorites Button with Badge count */}
          <Tooltip title="Favorites">
            <IconButton
              color="inherit"
              component={Link}
              to="/favorites"
              sx={{ color: "#000", "&:hover": { opacity: 0.7 } }}
            >
              <Badge 
                badgeContent={favoriteCount} 
                color="error"
                sx={{ "& .MuiBadge-badge": { fontSize: '0.7rem', bgcolor: "#000" } }}
              >
                <FavoriteBorderIcon sx={{ fontSize: "1.8rem" }} />
              </Badge>
            </IconButton>
          </Tooltip>

          {/* Cart Button with total item count */}
          <Tooltip title="Cart">
            <IconButton
              color="inherit"
              component={Link}
              to="/checkout"
              sx={{ color: "#000", "&:hover": { opacity: 0.7 } }}
            >
              <Badge 
                badgeContent={totalCount} 
                color="error"
                sx={{ "& .MuiBadge-badge": { fontSize: '0.7rem', bgcolor: "#000" } }}
              >
                <ShoppingCartIcon sx={{ fontSize: "1.8rem" }} />
              </Badge>
            </IconButton>
          </Tooltip>

        </Box>

      </Toolbar>
    </AppBar>
  );
}