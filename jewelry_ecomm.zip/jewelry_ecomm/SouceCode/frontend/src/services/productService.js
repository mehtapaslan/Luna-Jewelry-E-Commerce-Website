import api from "../api/axios";

/**
 * Fetches the most popular or featured products for the home display.
 * @returns {Promise<Array>} List of top products
 */
export const getTopProducts = async () => {
  const res = await api.get("/products/top");
  return res.data;
};

/**
 * Fetches the entire product collection.
 * @returns {Promise<Array>} List of all products
 */
export const getAllProducts = async () => {
  const res = await api.get("/products");
  return res.data;
};

/**
 * Fetches a single product's details using its unique identifier.
 * @param {string|number} id - Product ID
 * @returns {Promise<Object>} Product data
 */
export const getProductById = async (id) => {
  const res = await api.get(`/products/${id}`);
  return res.data;
};

/**
 * Fetches products filtered by category.
 * Includes custom logic to normalize plural category names to singular API endpoints.
 * @param {string} category - Category name (e.g., "Watches", "Rings")
 */
export const getProductsByCategory = async (category) => {
  let cat = category.toLowerCase();

  // SPECIAL CASE 1: Normalize 'Watches' to 'watch' to match API endpoint
  if (cat === 'watches') {
      cat = 'watch';
  } 
  // GENERAL RULE: Convert plural categories to singular by removing trailing 's'
  // Exception: 'Accessories' remains unchanged as it's handled differently by the backend
  else if (cat.endsWith('s') && cat !== 'accessories') {
      cat = cat.slice(0, -1);
  }

  const res = await api.get(`/products/category/${cat}`);
  return res.data;
};