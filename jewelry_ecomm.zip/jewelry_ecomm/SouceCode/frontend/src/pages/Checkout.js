import React, { useState } from "react";
import { Link } from "react-router-dom";
import { 
  Container, Typography, Box, Grid, Button, Divider, 
  CardMedia, IconButton, TextField, RadioGroup, FormControlLabel, Radio 
} from "@mui/material";

// Icons
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import DeleteIcon from "@mui/icons-material/Delete";

// Context & Assets
import { useCart } from "../context/CartContext";
import { resolveImageUrl } from "../config";

export default function Checkout() {
  const { items, add, decrement, remove, clear } = useCart();
  
  // State for toggling between Cart View and Payment Form
  const [showPayment, setShowPayment] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('card');

  // Calculate total price of all items in cart
  const totalPrice = items.reduce(
    (sum, it) => sum + it.price * (it.quantity || 1),
    0
  );

  // Empty Cart State
  if (items.length === 0) {
    return (
      <Container sx={{ py: 15, textAlign: 'center' }}>
        <Typography variant="h4" gutterBottom sx={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic' }}>
          Your cart is empty
        </Typography>
        <Button 
            variant="outlined" 
            component={Link} 
            to="/"
            sx={{ 
              color: '#000', 
              borderColor: '#000', 
              borderRadius: 0, 
              mt: 2, 
              '&:hover': { bgcolor: '#000', color: '#fff' } 
            }}
        >
          Go back to shopping
        </Button>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      {/* Page Header */}
      <Typography 
        variant="h4" 
        component="h1" 
        sx={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic', mb: 4, textAlign: 'center' }}
      >
        {showPayment ? "Checkout" : `Shopping Cart (${items.length})`}
      </Typography>

      <Grid container spacing={6}>
        {/* Main Content Area: List or Payment Form */}
        <Grid item xs={12} md={8}>
          
          {showPayment ? (
            /* SECTION: Shipping & Payment Form */
            <Box>
              <Typography variant="h6" sx={{ mb: 3, fontWeight: 'bold', textTransform: 'uppercase', fontSize: '0.85rem' }}>
                Shipping Address
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={6}><TextField fullWidth label="First Name" variant="standard" /></Grid>
                <Grid item xs={6}><TextField fullWidth label="Last Name" variant="standard" /></Grid>
                <Grid item xs={12}><TextField fullWidth label="Address" variant="standard" /></Grid>
                <Grid item xs={6}><TextField fullWidth label="City" variant="standard" /></Grid>
                <Grid item xs={6}><TextField fullWidth label="Postal Code" variant="standard" /></Grid>
              </Grid>

              <Divider sx={{ my: 5 }} />

              <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold', textTransform: 'uppercase', fontSize: '0.85rem' }}>
                Payment Method
              </Typography>
              <RadioGroup value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                <FormControlLabel value="card" control={<Radio color="default" />} label="Credit Card" />
                <FormControlLabel value="paypal" control={<Radio color="default" />} label="PayPal" />
              </RadioGroup>

              {paymentMethod === 'card' && (
                <Box sx={{ mt: 3, p: 3, bgcolor: '#f9f9f9' }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}><TextField fullWidth label="Card Number" variant="outlined" /></Grid>
                    <Grid item xs={6}><TextField fullWidth label="Expiry" placeholder="MM/YY" variant="outlined" /></Grid>
                    <Grid item xs={6}><TextField fullWidth label="CVC" variant="outlined" /></Grid>
                  </Grid>
                </Box>
              )}
              
              <Button onClick={() => setShowPayment(false)} sx={{ mt: 4, color: 'black', textDecoration: 'underline' }}>
                Back to cart
              </Button>
            </Box>
          ) : (
            /* SECTION: Product List View */
            <Box>
              <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
                <Button color="inherit" onClick={clear} size="small" sx={{ textTransform: 'lowercase', color: '#999', textDecoration: 'underline' }}>
                  clear cart
                </Button>
              </Box>
              <Divider sx={{ mb: 4 }} />
              
              {items.map((item) => (
                <Box key={item.id} sx={{ mb: 4 }}>
                  <Grid container alignItems="center" spacing={3}>
                    {/* Item Image */}
                    <Grid item xs={4} sm={3}>
                      <Box sx={{ bgcolor: '#f9f9f9', p: 1, display: 'flex', justifyContent: 'center' }}>
                          <CardMedia 
                            component="img" 
                            image={resolveImageUrl(item.imageUrl)} 
                            alt={item.name} 
                            sx={{ height: 120, width: "auto", objectFit: 'contain' }} 
                          />
                      </Box>
                    </Grid>
                    
                    {/* Item Details & Actions */}
                    <Grid item xs={8} sm={9}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                        <Box>
                            <Typography variant="h6" sx={{ fontWeight: "bold", textTransform: "uppercase", letterSpacing: 1.5, fontSize: "0.85rem", color: "#000" }}>
                              {item.name}
                            </Typography>
                            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
                              ${item.price.toLocaleString()} each
                            </Typography>
                        </Box>
                        <IconButton onClick={() => remove(item.id)} size="small">
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Box>
                      
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 3 }}>
                          {/* Quantity Controls */}
                          <Box sx={{ display: 'flex', alignItems: 'center', border: '1px solid #ddd' }}>
                            <IconButton onClick={() => decrement(item.id)} size="small" sx={{ borderRadius: 0 }}>
                              <RemoveIcon fontSize="small" />
                            </IconButton>
                            <Typography sx={{ px: 2, fontWeight: 'bold' }}>{item.quantity || 1}</Typography>
                            <IconButton onClick={() => add(item)} size="small" sx={{ borderRadius: 0 }}>
                              <AddIcon fontSize="small" />
                            </IconButton>
                          </Box>
                          
                          {/* Item Subtotal */}
                          <Typography variant="subtitle1" sx={{ fontWeight: 'bold', fontFamily: "'Playfair Display', serif" }}>
                            ${(item.price * (item.quantity || 1)).toLocaleString()}
                          </Typography>
                      </Box>
                    </Grid>
                  </Grid>
                  <Divider sx={{ mt: 4, borderColor: '#f0f0f0' }} />
                </Box>
              ))}
            </Box>
          )}
        </Grid>

        {/* RIGHT SIDEBAR: Order Summary (Sticky) */}
        <Grid item xs={12} md={4}>
            <Box sx={{ bgcolor: '#f9f9f9', p: 4, position: 'sticky', top: '100px' }}>
                <Typography variant="h5" sx={{ fontFamily: "'Playfair Display', serif", mb: 3 }}>
                  Order Summary
                </Typography>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                    <Typography variant="body1">Subtotal</Typography>
                    <Typography variant="body1">${totalPrice.toLocaleString()}</Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 4 }}>
                    <Typography variant="body1">Shipping</Typography>
                    <Typography variant="body1" sx={{ color: '#666' }}>Complimentary</Typography>
                </Box>
                
                <Divider sx={{ mb: 3 }} />
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 4 }}>
                    <Typography variant="h6" sx={{ fontFamily: "'Playfair Display', serif", fontWeight: 'bold' }}>Total</Typography>
                    <Typography variant="h6" sx={{ fontFamily: "'Playfair Display', serif", fontWeight: 'bold' }}>
                      ${totalPrice.toLocaleString()}
                    </Typography>
                </Box>

                <Button
                    variant="contained"
                    fullWidth
                    size="large"
                    onClick={() => {
                        if(!showPayment) setShowPayment(true);
                        else alert("Thank you for your purchase!");
                    }}
                    sx={{ 
                      bgcolor: "black", 
                      color: "white", 
                      borderRadius: 0, 
                      py: 1.5, 
                      textTransform: "uppercase", 
                      letterSpacing: 2, 
                      "&:hover": { bgcolor: "#333" } 
                    }}
                >
                    {showPayment ? "Complete Purchase" : "Proceed to Checkout"}
                </Button>
            </Box>
        </Grid>
      </Grid>
    </Container>
  );
}