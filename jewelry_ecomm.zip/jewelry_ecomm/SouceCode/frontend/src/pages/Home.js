import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

// Material UI Components
import { 
  Container, Grid, Typography, Box, Stack, Button, 
  List, ListItem, ListItemText, Divider, ListItemIcon 
} from '@mui/material'; 

// Icons
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
import SupportAgentOutlinedIcon from '@mui/icons-material/SupportAgentOutlined';
import CalendarTodayOutlinedIcon from '@mui/icons-material/CalendarTodayOutlined';

// Project Components & Services
import HeroImage from './photoshoot.jpeg';
import ProductCard from '../components/ProductCard';
import { getAllProducts, getProductsByCategory } from '../services/productService';

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("All");

  const categories = ["All", "Rings", "Bracelets", "Necklaces", "Earrings", "Watches", "Accessories"];

  /**
   * Data Fetching Logic
   * Triggers whenever the selectedCategory state changes.
   */
  useEffect(() => {
    let mounted = true;
    setLoading(true);

    // Determine which service function to call based on category
    const fetchOperation = selectedCategory === "All" 
      ? getAllProducts() 
      : getProductsByCategory(selectedCategory);

    fetchOperation
      .then((data) => {
        if (mounted) {
          setProducts(data || []);
          setLoading(false);
        }
      })
      .catch((err) => {
        console.error("Home Fetch Error:", err);
        if (mounted) setLoading(false);
      });

    // Cleanup function to prevent state updates on unmounted component
    return () => {
      mounted = false;
    };
  }, [selectedCategory]);

  return (
    <Box>
      {/* SECTION: HERO PART - Full-width brand introduction */}
      <Box sx={{ 
          height: '70vh', 
          width: '100%',
          backgroundImage: `url(${HeroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          display: 'flex', 
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          color: 'white',
          textAlign: 'center',
          position: 'relative'
      }}>
          {/* Overlay for better text readability */}
          <Box sx={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, bgcolor: 'rgba(0,0,0,0.3)' }} />
          
          <Box sx={{ position: 'relative', zIndex: 1 }}>
            <Typography variant="h2" 
              sx={{ 
                fontFamily: "'Playfair Display', serif",
                fontStyle: 'italic',
                mb: 2, 
                fontSize: { xs: '3rem', md: '5rem'},
                textShadow: '2px 2px 10px rgba(0,0,0,0.5)'
              }}
            >
              Timeless & Iconic
            </Typography>
            <Typography variant="subtitle2" sx={{ letterSpacing: 4, fontWeight: 'bold', textTransform: 'uppercase' }}>
              Discover the Luna's unique pieces and one-of-a-kind creations.
            </Typography>
          </Box>
      </Box>

      {/* SECTION: MAIN CONTENT - Category filters, Sidebar, and Product Grid */}
      <Container maxWidth="xl" sx={{ py: 5, minHeight: '80vh' }}>
        
        {/* Category Navigation Bar */}
        <Box sx={{ display: 'flex', justifyContent: 'center', mb: 6 }}>
          <Stack 
            direction="row" 
            spacing={{ xs: 2, md: 4 }} 
            sx={{ overflowX: 'auto', py: 1 }}
          >
            {categories.map((cat) => (
              <Button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                disableRipple
                sx={{ 
                  minWidth: 'auto',
                  padding: 0,
                  borderRadius: 0,
                  textTransform: 'uppercase',
                  fontSize: '0.75rem',
                  letterSpacing: '1px',
                  color: selectedCategory === cat ? '#000' : '#999',
                  fontWeight: selectedCategory === cat ? 'bold' : 'normal',
                  borderBottom: selectedCategory === cat ? '1px solid #000' : '1px solid transparent',
                  '&:hover': { bgcolor: 'transparent', color: '#000' }
                }}
              >
                {cat}
              </Button>
            ))}
          </Stack>
        </Box>

        <Grid container spacing={6}>
          
          {/* LEFT SIDEBAR: Customer Care Navigation */}
          <Grid item xs={12} md={3} lg={2} sx={{ display: { xs: 'none', md: 'block' } }}> 
            <Box sx={{ position: 'sticky', top: '120px' }}>
              <Typography variant="h6" sx={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic', mb: 2 }}>
                Customer Care
              </Typography>
              <Divider sx={{ mb: 2 }} />

              <List>
                <ListItem button component={Link} to="/profile" sx={{ pl: 0, mb: 1 }}>
                  <ListItemIcon sx={{ minWidth: 35 }}>
                    <PersonOutlineIcon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary="My Profile" primaryTypographyProps={{ fontSize: '0.9rem', color: '#555' }} />
                </ListItem>

                <ListItem button component={Link} to="/stores" sx={{ pl: 0, mb: 1 }}>
                  <ListItemIcon sx={{ minWidth: 35 }}>
                    <LocationOnOutlinedIcon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary="Store Locator" primaryTypographyProps={{ fontSize: '0.9rem', color: '#555' }} />
                </ListItem>

                <ListItem button component={Link} to="/contact" sx={{ pl: 0, mb: 1 }}>
                  <ListItemIcon sx={{ minWidth: 35 }}>
                    <SupportAgentOutlinedIcon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary="Contact Us" primaryTypographyProps={{ fontSize: '0.9rem', color: '#555' }} />
                </ListItem>

                <ListItem button component={Link} to="/appointment" sx={{ pl: 0 }}>
                 <ListItemIcon sx={{ minWidth: 35 }}>
                  <CalendarTodayOutlinedIcon fontSize="small" />
                 </ListItemIcon>
                 <ListItemText primary="Book Appointment" primaryTypographyProps={{ fontSize: '0.9rem', color: '#555' }} />
                </ListItem>
              </List>
            </Box>
          </Grid>

          {/* RIGHT SECTION: Product Showcase Grid */}
          <Grid item xs={12} md={9} lg={10}>
            <Typography 
              variant="h4" 
              component="h1" 
              sx={{ 
                fontFamily: "'Playfair Display', serif", 
                fontStyle: 'italic',
                mb: 4,
              }}
            >
              {selectedCategory === "All" ? "New Arrivals" : selectedCategory}
            </Typography>

            {loading ? (
              <Typography sx={{ mt: 5, color: '#999' }}>Loading collection...</Typography>
            ) : (
              <Grid container spacing={3}>
                {products.length > 0 ? (
                  products.map((p) => (
                    <Grid item key={p.id} xs={6} sm={6} md={4} lg={3}>
                      <ProductCard product={p} />
                    </Grid>
                  ))
                ) : (
                  <Typography sx={{ p: 2, color: '#999' }}>
                    No products found in this category.
                  </Typography>
                )}
              </Grid>
            )}
          </Grid>

        </Grid>
      </Container>
    </Box>
  );
}