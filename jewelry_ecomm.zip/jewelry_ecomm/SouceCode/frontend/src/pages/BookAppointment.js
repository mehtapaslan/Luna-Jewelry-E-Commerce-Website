import React, { useState } from "react";
import { 
  Container, Grid, Typography, Box, TextField, 
  Button, MenuItem, Divider 
} from "@mui/material";
import AppImage from './appointment-hero-mobile.jpeg';

export default function BookAppointment() {
  // Form state management
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    type: "Consultation",
    date: "",
    message: ""
  });

  // Handle input changes dynamically
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    // Placeholder for backend integration
    alert(`Thank you, ${formData.name}. We have received your appointment request.`);
  };

  // Options for the appointment type dropdown
  const appointmentTypes = [
    { value: "Consultation", label: "Jewelry Consultation" },
    { value: "Bridal", label: "Bridal & Engagement" },
    { value: "Repair", label: "Repair & Care" },
    { value: "Viewing", label: "Private Viewing" },
  ];

  return (
    <Container maxWidth="lg" sx={{ py: 10 }}>
      <Grid container spacing={8} alignItems="center">
        
        {/* LEFT SECTION: Atmospheric Visuals */}
        <Grid item xs={12} md={6}>
          <Box sx={{ position: 'relative', height: '600px', bgcolor: '#f0f0f0', overflow: 'hidden' }}>
            <img
              src={AppImage} 
              alt="Boutique Interior" 
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
            {/* Overlay text on image */}
            <Box sx={{ 
              position: 'absolute', 
              bottom: 40, 
              left: 40, 
              color: 'white', 
              textShadow: '1px 1px 10px rgba(0,0,0,0.5)' 
            }}>
              <Typography variant="h4" sx={{ fontFamily: "'Pinyon Script', cursive" }}>
                The Luna Experience
              </Typography>
              <Typography variant="body2" sx={{ letterSpacing: 1, mt: 1, textTransform: 'uppercase' }}>
                Expertise & Passion
              </Typography>
            </Box>
          </Box>
        </Grid>

        {/* RIGHT SECTION: Appointment Form */}
        <Grid item xs={12} md={6}>
          <Typography 
                  variant="h4" 
                  component="h1" 
                  sx={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic', mb: 4, textAlign: 'center' }}
                >
            Book an Appointment
          </Typography>
          
          <Typography variant="body1" sx={{ color: '#666', mb: 5, fontStyle: 'italic', fontFamily: "'Playfair Display', serif" }}>
            Whether you wish to explore our latest collections, create a custom piece, 
            or require maintenance for your jewelry, we are here to assist you.
          </Typography>

          <form onSubmit={handleSubmit}>
            <Grid container spacing={3}>
                
                {/* Full Name Input */}
                <Grid item xs={12}>
                    <TextField 
                        fullWidth 
                        label="Full Name" 
                        name="name"
                        variant="standard" 
                        value={formData.name}
                        onChange={handleChange}
                        required
                    />
                </Grid>

                {/* Email Address Input */}
                <Grid item xs={12}>
                    <TextField 
                        fullWidth 
                        label="Email Address" 
                        name="email"
                        type="email"
                        variant="standard" 
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                </Grid>

                {/* Service Selection Dropdown */}
                <Grid item xs={12}>
                    <TextField
                        select
                        fullWidth
                        label="Appointment Type"
                        name="type"
                        variant="standard"
                        value={formData.type}
                        onChange={handleChange}
                    >
                        {appointmentTypes.map((option) => (
                        <MenuItem key={option.value} value={option.value}>
                            {option.label}
                        </MenuItem>
                        ))}
                    </TextField>
                </Grid>

                {/* Preferred Date Input */}
                <Grid item xs={12}>
                    <TextField
                        fullWidth
                        name="date"
                        type="date"
                        variant="standard"
                        helperText="Preferred Date"
                        value={formData.date}
                        onChange={handleChange}
                        InputLabelProps={{ shrink: true }}
                    />
                </Grid>

                {/* Additional Notes Textarea */}
                <Grid item xs={12}>
                    <TextField 
                        fullWidth 
                        label="Additional Notes (Optional)" 
                        name="message"
                        multiline
                        rows={3}
                        variant="standard" 
                        value={formData.message}
                        onChange={handleChange}
                    />
                </Grid>

                {/* Form Action Button */}
                <Grid item xs={12} sx={{ mt: 2 }}>
                    <Button 
                        type="submit"
                        variant="contained" 
                        fullWidth
                        sx={{ 
                            bgcolor: '#000', 
                            color: '#fff', 
                            borderRadius: 0, 
                            py: 2,
                            letterSpacing: 2,
                            fontWeight: 'bold',
                            '&:hover': { bgcolor: '#333' }
                        }}
                    >
                        Request Appointment
                    </Button>
                </Grid>
            </Grid>
          </form>

          <Divider sx={{ my: 5 }} />

          {/* Contact Details Footer */}
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="caption" sx={{ color: '#999', textTransform: 'uppercase', letterSpacing: 1 }}>
                Or contact us directly
            </Typography>
            <Typography variant="body1" sx={{ mt: 1, fontFamily: "'Playfair Display', serif" }}>
                +1 (800) LUNA-VIP
            </Typography>
          </Box>
        </Grid>

      </Grid>
    </Container>
  );
}