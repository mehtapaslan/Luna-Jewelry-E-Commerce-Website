import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

// Material UI Components
import { 
  Container, Grid, Typography, Button, Box, 
  CircularProgress, Divider, Alert 
} from "@mui/material";

// Icons
import ShoppingBagOutlinedIcon from '@mui/icons-material/ShoppingBagOutlined';
import SyncAltOutlinedIcon from '@mui/icons-material/SyncAltOutlined';

// Project Services & Context
import { getProductById } from "../services/productService";
import { useCart } from "../context/CartContext";
import { resolveImageUrl } from "../config";

export default function ProductDetail() {
  const { id } = useParams();
  const { add } = useCart();

  // Component States
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [notification, setNotification] = useState(false);

  /**
   * Effect Hook: Fetches product details by ID
   * Includes a cleanup flag (cancelled) to prevent memory leaks 
   * and state updates on unmounted components.
   */
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    getProductById(id)
      .then((data) => {
        if (!cancelled) {
          setProduct(data);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err?.message || "Error loading product");
          setLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [id]);

  /**
   * Action: Adds product to cart and triggers success notification
   */
  const handleAddToCart = () => {
    if (product) {
      add(product);
      setNotification(true);
      setTimeout(() => setNotification(false), 3000);
    }
  };

  // Loading and Error States
  if (loading) return <Container sx={{ py: 15, textAlign: 'center' }}><CircularProgress sx={{ color: 'black' }} /></Container>;
  if (error || !product) return <Container sx={{ py: 15, textAlign: 'center' }}><Typography variant="h5">Product not found.</Typography></Container>;

  const priceText = typeof product.price === "number" ? product.price.toLocaleString() : product.price;
  const displayText = product.details || product.description;

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      
      <Grid container spacing={6} alignItems="flex-start">
        
        {/* LEFT SECTION: Visual Display - Main Product Image */}
        <Grid item xs={12} md={6}>
          <Box 
            sx={{ 
                width: '100%',
                height: '500px', 
                bgcolor: '#f0f0f0', 
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                overflow: 'hidden', 
                border: '1px solid #eee' 
            }}
          >
            <img
              src={resolveImageUrl(product.imageUrl)}
              alt={product.name}
              style={{
                width: "100%",  
                height: "100%", 
                objectFit: "cover", // Maintains aspect ratio while filling container
                display: "block"
              }}
            />
          </Box>
        </Grid>

        {/* RIGHT SECTION: Product Information & Purchase Actions */}
        <Grid item xs={12} md={6} sx={{ pl: { md: 4 } }}>
          
          {/* Product Name Header */}
          <Typography 
            variant="h6"
            sx={{ 
              fontWeight: "bold", 
              textTransform: "uppercase", 
              letterSpacing: 1.5, 
              fontSize: "1.5rem",
              color: "#000"
            }}
          >
            {product.name}
          </Typography>

          {/* Pricing Details */}
          <Typography 
            variant="h6" 
            sx={{ fontWeight: "bold", mt: 1, color: "#000", fontSize: "1.3rem" }}
          >
            ${priceText}
          </Typography>

          {/* Product Description - Elegant serif font */}
          {displayText && (
            <Typography 
                variant="body1" 
                sx={{ 
                    fontFamily: "'Playfair Display', serif", 
                    fontStyle: "italic", 
                    color: '#555', 
                    fontSize: "1rem",
                    mb: 4, 
                    lineHeight: 1.6
                }}
            >
              {displayText}
            </Typography>
          )}

          {/* SECTION: Complimentary Services - Highlighting brand benefits */}
          <Box sx={{ mb: 5, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            
            {/* Shipping Service */}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <ShoppingBagOutlinedIcon sx={{ fontSize: '1.2rem', color: '#333' }} />
                <Typography variant="caption" sx={{ fontSize: '0.7rem', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: 1, color: '#333' }}>
                    Complimentary Shipping
                </Typography>
            </Box>

            {/* Return Policy Service */}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <SyncAltOutlinedIcon sx={{ fontSize: '1.2rem', color: '#333' }} />
                <Typography variant="caption" sx={{ fontSize: '0.7rem', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: 1, color: '#333' }}>
                    Complimentary Returns & Exchanges
                </Typography>
            </Box>

          </Box>

          {/* Purchase Button Action */}
          <Button
            variant="contained"
            onClick={handleAddToCart}
            fullWidth
            sx={{
                bgcolor: "black",
                color: "white",
                borderRadius: 0, 
                py: 2,
                textTransform: "uppercase",
                letterSpacing: "2px", 
                fontSize: "0.8rem",
                fontWeight: 'bold',
                mb: 3,
                boxShadow: 'none',
                "&:hover": { bgcolor: "#333", boxShadow: 'none' }
            }}
          >
            Add to Shopping Cart
          </Button>

          {/* Temporary Success Message */}
          {notification && (
            <Alert 
              severity="success" 
              sx={{ borderRadius: 0, mb: 3, bgcolor: '#f9f9f9', color: '#000', border: '1px solid #eee' }}
            >
              Product added to cart.
            </Alert>
          )}

          <Divider sx={{ my: 3, borderColor: '#eee' }} />

          {/* SECTION: Customer Care & Additional Inquiries */}
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Typography variant="caption" sx={linkStyle}>+ Book an Appointment</Typography>
            <Typography variant="caption" sx={linkStyle}>+ Order By Phone</Typography>
            <Typography variant="caption" sx={linkStyle}>+ Find In Boutique</Typography>
            <Typography variant="caption" sx={linkStyle}>+ Contact An Ambassador</Typography>
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
}

// Reusable style for secondary links
const linkStyle = { 
  fontWeight: 'bold', 
  cursor: 'pointer', 
  letterSpacing: 1, 
  textTransform: 'uppercase', 
  color: '#666', 
  '&:hover': { color: 'black'} 
};