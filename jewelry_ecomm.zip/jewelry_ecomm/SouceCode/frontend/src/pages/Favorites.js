import React from "react";
import { Link } from "react-router-dom";
import { Container, Grid, Typography, Button } from "@mui/material";

// Components & Context
import ProductCard from "../components/ProductCard";
import { useFavorites } from "../context/FavoritesContext";

export default function Favorites() {
  // Access favorite items from the global context
  const { favorites } = useFavorites();

  // Condition: Display a placeholder if no favorites are present
  if (favorites.length === 0) {
    return (
      <Container sx={{ py: 15, textAlign: 'center' }}>
        <Typography 
          variant="h4" 
          gutterBottom 
          sx={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic' }}
        >
          Your favorites is empty
        </Typography>

        {/* Minimalist outlined button for navigation */}
        <Button 
          variant="outlined" 
          component={Link} 
          to="/"
          sx={{ 
            color: '#000', 
            borderColor: '#000', 
            borderRadius: 0, 
            mt: 2,
            '&:hover': { bgcolor: '#000', color: '#fff' }
          }}
        >
          GO BACK TO SHOPPING
        </Button>
      </Container>
    );
  }

  // Condition: Render the list of favorite products
  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      {/* Page Title showing dynamic item count */}
      <Typography 
        variant="h4" 
        component="h1" 
        sx={{ 
          fontFamily: "'Playfair Display', serif", 
          fontStyle: 'italic', 
          mb: 4, 
          textAlign: 'center' 
        }}
      >
        My Favorites ({favorites.length})
      </Typography>

      <Grid container spacing={3}>
        {/* Iterate through favorites array and render a ProductCard for each */}
        {favorites.map((product) => (
          <Grid item key={product.id} xs={12} sm={6} md={4} lg={3}>
            <ProductCard product={product} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}