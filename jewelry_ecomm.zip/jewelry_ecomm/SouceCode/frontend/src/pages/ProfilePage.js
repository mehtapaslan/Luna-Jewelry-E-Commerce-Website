import React from 'react';
import { 
  Container, Grid, Typography, Box, Paper, 
  Button, Divider, Avatar 
} from '@mui/material';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';

export default function ProfilePage() {
  // Mock data for orders (In a real application, this would be fetched from an API)
  const orders = [
    { id: '#LUNA-8821', date: 'Dec 24, 2025', total: '$1,250.00', status: 'Delivered' },
    { id: '#LUNA-8902', date: 'Jan 02, 2026', total: '$450.00', status: 'Processing' },
  ];

  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      <Grid container spacing={4}>
        
        {/* LEFT SECTION: User Profile Summary Card */}
        <Grid item xs={12} md={4}>
          <Paper 
            elevation={0} 
            sx={{ p: 4, bgcolor: '#f9f9f9', textAlign: 'center' }}
          >
            {/* User Avatar with branding color */}
            <Avatar 
              sx={{ 
                width: 80, 
                height: 80, 
                margin: '0 auto', 
                bgcolor: 'black', 
                mb: 2 
              }}
            >
              <PersonOutlineIcon sx={{ fontSize: 40 }} />
            </Avatar>
            
            <Typography variant="h5" sx={{ fontFamily: "'Playfair Display', serif" }}>
              Mehtap Aslan
            </Typography>
            
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              mehtap@example.com
            </Typography>
            
            {/* Profile Action - Styled to match brand guidelines */}
            <Button 
              variant="outlined" 
              fullWidth 
              sx={{ 
                borderRadius: 0, 
                color: 'black', 
                borderColor: 'black',
                '&:hover': { borderColor: '#333', bgcolor: 'rgba(0,0,0,0.05)' } 
              }}
            >
              Edit Profile
            </Button>
          </Paper>
        </Grid>

        {/* RIGHT SECTION: Order History & Activity */}
        <Grid item xs={12} md={8}>
          <Typography 
            variant="h5" 
            sx={{ fontFamily: "'Playfair Display', serif", mb: 3 }}
          >
            Recent Orders
          </Typography>
          
          <Divider sx={{ mb: 3 }} />

          {/* Render orders dynamically from the mock data array */}
          {orders.map((order) => (
            <Box 
              key={order.id} 
              sx={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center', 
                mb: 3, 
                pb: 2, 
                borderBottom: '1px solid #eee' 
              }}
            >
              {/* Order Basic Info */}
              <Box>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                  {order.id}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {order.date}
                </Typography>
              </Box>
              
              {/* Order Financials & Fulfillment Status */}
              <Box sx={{ textAlign: 'right' }}>
                <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                  {order.total}
                </Typography>
                <Typography 
                  variant="caption" 
                  sx={{ 
                    color: order.status === 'Delivered' ? 'green' : 'orange',
                    textTransform: 'uppercase',
                    fontWeight: 'bold'
                  }}
                >
                  {order.status}
                </Typography>
              </Box>
            </Box>
          ))}
        </Grid>
        
      </Grid>
    </Container>
  );
}