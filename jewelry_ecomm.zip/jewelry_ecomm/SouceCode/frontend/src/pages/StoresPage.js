import React from 'react';
import { Container, Typography, Grid, Box, Button, Divider, Paper } from '@mui/material';

// Store data defined in a clean array for easy updates
const stores = [
  {
    city: "Istanbul",
    address: "Abdi İpekçi Cad. No:12, Nişantaşı",
    phone: "+90 212 555 0000",
    hours: "Mon-Sat: 10am - 8pm"
  },
  {
    city: "Paris",
    address: "15 Place Vendôme, 75001 Paris",
    phone: "+33 1 44 55 66 77",
    hours: "Mon-Sat: 11am - 7pm"
  },
  {
    city: "New York",
    address: "730 Fifth Avenue, NY 10019",
    phone: "+1 212 333 4444",
    hours: "Mon-Sun: 10am - 9pm"
  }
];

export default function StoresPage() {
  return (
    <Container maxWidth="lg" sx={{ py: 10 }}>
      
      {/* SECTION: Page Header - Using signature fonts */}
      <Typography 
        variant="h2" 
        align="center" 
        sx={{ 
          fontFamily: "'Playfair Display', serif", 
          fontStyle: 'italic', 
          mb: 2,
          fontSize: { xs: '2.5rem', md: '3.5rem' } 
        }}
      >
        Our Boutiques
      </Typography>
      
      <Typography 
        variant="body1" 
        align="center" 
        sx={{ 
          mb: 8, 
          color: '#666', 
          maxWidth: 500, 
          mx: 'auto', 
          lineHeight: 1.8 
        }}
      >
        Visit us to experience the craftsmanship and elegance of Luna Jewelry in person.
      </Typography>

      {/* Grid Layout for store cards */}
      <Grid container spacing={5} justifyContent="center">
        {stores.map((store) => (
          <Grid item xs={12} md={4} key={store.city}>
            
            {/* Store Boutique Card - Minimalist & Luxury style */}
            <Paper 
              elevation={0}
              sx={{ 
                p: 5, 
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                textAlign: 'center',
                border: '1px solid #e0e0e0',
                borderRadius: 0,
                transition: '0.4s ease',
                '&:hover': { 
                  borderColor: '#000',
                  transform: 'translateY(-5px)',
                  boxShadow: '0 10px 30px rgba(0,0,0,0.05)' 
                }
              }}
            >
              {/* City Name - Signature style logo font */}
              <Typography 
                variant="h3" 
                sx={{ 
                  fontFamily: "'Pinyon Script', cursive", 
                  color: '#000',
                  mb: 3
                }}
              >
                {store.city}
              </Typography>

              {/* Decorative Divider */}
              <Divider sx={{ width: '40px', borderColor: '#000', mb: 3 }} />

              {/* Store Contact & Address details */}
              <Box sx={{ mb: 4, flexGrow: 1 }}>
                <Typography 
                  variant="body1" 
                  sx={{ fontFamily: "'Playfair Display', serif", mb: 1, fontSize: '1.1rem' }}
                >
                  {store.address}
                </Typography>
                
                <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                  {store.phone}
                </Typography>
                
                <Typography 
                  variant="caption" 
                  sx={{ textTransform: 'uppercase', color: '#999', letterSpacing: 1 }}
                >
                  {store.hours}
                </Typography>
              </Box>

              {/* External Link Action */}
              <Button 
                variant="outlined" 
                fullWidth
                sx={{ 
                  borderRadius: 0, 
                  color: 'black', 
                  borderColor: 'black',
                  textTransform: 'uppercase',
                  letterSpacing: '2px',
                  fontSize: '0.75rem',
                  py: 1.5,
                  '&:hover': { bgcolor: 'black', color: 'white', borderColor: 'black' }
                }}
              >
                Get Directions
              </Button>

            </Paper>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}