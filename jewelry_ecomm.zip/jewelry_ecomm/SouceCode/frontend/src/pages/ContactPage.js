import React from 'react';
import { 
  Container, Grid, Typography, TextField, 
  Button, Box, Divider 
} from '@mui/material';

export default function ContactPage() {
  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      {/* Page Title - Elegant serif font for luxury branding */}
      <Typography 
        variant="h3" 
        align="center" 
        sx={{ 
          fontFamily: "'Playfair Display', serif", 
          fontStyle: 'italic', 
          mb: 6 
        }}
      >
        Contact Us
      </Typography>

      <Grid container spacing={8}>
        
        {/* LEFT SECTION: Contact Details & Client Services */}
        <Grid item xs={12} md={5}>
          <Typography 
            variant="h6" 
            sx={{ textTransform: 'uppercase', letterSpacing: 1, mb: 2 }}
          >
            Client Services
          </Typography>
          
          <Typography variant="body1" sx={{ color: '#555', mb: 4, lineHeight: 1.8 }}>
            Luna Jewelry ambassadors are at your disposal to share their passion and assist you.
          </Typography>

          <Divider sx={{ mb: 3 }} />

          {/* Contact Information Blocks */}
          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>PHONE</Typography>
            <Typography variant="body2" color="text.secondary">+1 800 LUNA (5862)</Typography>
          </Box>

          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>EMAIL</Typography>
            <Typography variant="body2" color="text.secondary">concierge@lunajewelry.com</Typography>
          </Box>

          <Box>
            <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>ADDRESS</Typography>
            <Typography variant="body2" color="text.secondary">
              123 Luxury Ave, Manhattan<br />
              New York, NY 10012
            </Typography>
          </Box>
        </Grid>

        {/* RIGHT SECTION: Contact Inquiry Form */}
        <Grid item xs={12} md={7}>
          <form noValidate autoComplete="off">
            <Grid container spacing={3}>
              
              <Grid item xs={12} sm={6}>
                <TextField 
                  label="First Name" 
                  variant="standard" 
                  fullWidth 
                />
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField 
                  label="Last Name" 
                  variant="standard" 
                  fullWidth 
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField 
                  label="Email" 
                  variant="standard" 
                  fullWidth 
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField 
                  label="Message" 
                  variant="standard" 
                  multiline 
                  rows={4} 
                  fullWidth 
                />
              </Grid>
              
              <Grid item xs={12}>
                <Button 
                  variant="contained" 
                  fullWidth
                  sx={{ 
                    bgcolor: 'black', 
                    borderRadius: 0, 
                    py: 1.5,
                    mt: 2,
                    textTransform: 'uppercase',
                    letterSpacing: 2,
                    '&:hover': { bgcolor: '#333' }
                  }}
                >
                  Send Message
                </Button>
              </Grid>
              
            </Grid>
          </form>
        </Grid>
        
      </Grid>
    </Container>
  );
}