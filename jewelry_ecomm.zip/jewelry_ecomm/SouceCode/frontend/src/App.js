import React from "react";
import { Routes, Route } from "react-router-dom";

// Material UI Core
import { CssBaseline } from '@mui/material';

// Context Providers
import { CartProvider } from "./context/CartContext";
import { FavoritesProvider } from './context/FavoritesContext';

// Layout Components
import Header from "./components/Header";
import Footer from "./components/Footer";
import ScrollToTop from "./components/ScrollToTop";

// Pages
import Home from "./pages/Home";
import Checkout from "./pages/Checkout";
import ProductDetail from "./pages/ProductDetail";
import ContactPage from './pages/ContactPage';
import ProfilePage from './pages/ProfilePage';
import StoresPage from './pages/StoresPage';
import Favorites from './pages/Favorites';
import BookAppointment from "./pages/BookAppointment";

/**
 * Main Application Component
 * Wraps the entire app with necessary Context Providers and defines the Routing table.
 */
function App() {
  return (
    <FavoritesProvider>
      <CartProvider>
        {/* Normalizes styles across different browsers */}
        <CssBaseline />
        
        {/* Resets scroll position to top on every navigation change */}
        <ScrollToTop />
        
        {/* Navigation bar remains visible across all routes */}
        <Header />
        
        <Routes>
          {/* Core E-commerce Routes */}
          <Route path="/" element={<Home />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/products/:id" element={<ProductDetail />} />
          <Route path="/favorites" element={<Favorites />} />
          
          {/* Static and Utility Pages */}
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/stores" element={<StoresPage />} />
          <Route path="/appointment" element={<BookAppointment />} />
        </Routes>
        
        {/* Footer remains visible across all routes */}
        <Footer />
      </CartProvider>
    </FavoritesProvider>
  );
}

export default App;